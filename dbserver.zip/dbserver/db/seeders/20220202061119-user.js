'use strict';

module.exports = {
  async up (queryInterface, Sequelize) {
    await queryInterface.bulkInsert('Users', [
      {
       name: 'Ganesh',
       mobileNo: 8928158181,
       email:'ganesh@gmail.com',
       password:'Gamesh@123',
       createdAt: new Date(),
       updatedAt: new Date()
     },
     {
      name: 'Triveni',
      mobileNo: 7698585793,
      email:'triveni4@gmail.com',
      password:'Triveni@10',
      createdAt: new Date(),
      updatedAt: new Date()
    },



    ], {});
  },


  async down (queryInterface, Sequelize) {
    /**
     * Add commands to revert seed here.
     *
     * Example:
     * await queryInterface.bulkDelete('People', null, {});
     */
  }
};