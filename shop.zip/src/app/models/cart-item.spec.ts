import { CartItem } from './cart-item';


describe('Cart', () => {
  it('should create an instance', () => {
   // expect(new CartItem()).toBeTruthy();
  });
});
